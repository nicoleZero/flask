# _*_ coding: utf-8 _*_

DEBUG = True
SQLALCHEMY_TRACK_MODIFICATIONS = False
SECRET_KEY='A0Zr98j/3yX R~XHH!jmN]LWX/,?RT'
SQLALCHEMY_DATABASE_URI = "mysql+pymysql://root:@localhost:3306/BLOG_DB"